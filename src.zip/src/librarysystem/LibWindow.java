package librarysystem;

public interface LibWindow {
	void init();
	boolean isInitialized();
	void isInitialized(boolean val);
	void setVisible(boolean b);
}

